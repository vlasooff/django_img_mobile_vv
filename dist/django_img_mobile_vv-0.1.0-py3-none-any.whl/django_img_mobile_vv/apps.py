from django.apps import AppConfig 


class IMGMobileVVConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_img_mobile_vv' 
